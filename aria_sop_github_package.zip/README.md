# ARIA · 新智汇 — SOP Collaboration Workspace

> AI-Driven IT Delivery Platform · Sunline Tech · Pilot M1–M2

A shared SOP workspace for all 7 ARIA delivery roles — PM, BA, Integration TA, Functional TA, Developer, Tester, and MA.

---

## 🌐 Live Site

Once GitHub Pages is enabled, your team accesses the workspace at:

```
https://<your-github-username>.github.io/aria-sop-workspace/
```

---

## 👥 Roles Covered

| Role | Steps | Focus |
|---|---|---|
| 📋 PM | 9 | Project governance, planning, reporting |
| 📝 BA | 7 | Requirements, user stories, UAT |
| 🔌 Integration TA | 7 | AWS, OceanBase, AgentCore, IaC |
| 🏦 Functional TA | 7 | Core banking, FSD, regulatory compliance |
| 💻 Developer | 7 | Build, test, implementation, release |
| 🧪 Tester | 6 | Test strategy, SIT, UAT, quality reporting |
| 🛠️ MA | 6 | Monitoring, incidents, change management |

---

## 🚀 How to Deploy (5 Steps)

### Step 1 — Create a GitHub repository

1. Go to [github.com](https://github.com) and sign in
2. Click **New repository**
3. Name it: `aria-sop-workspace`
4. Set visibility to **Private** (recommended for internal team use)
5. Click **Create repository**

---

### Step 2 — Upload files to the repository

Upload both files from this package:
- `index.html` — the SOP workspace application
- `README.md` — this file

**Option A — Via GitHub web interface (easiest):**
1. Open your new repository
2. Click **Add file → Upload files**
3. Drag and drop both files
4. Click **Commit changes**

**Option B — Via Git command line:**
```bash
git clone https://github.com/<your-username>/aria-sop-workspace.git
cd aria-sop-workspace
cp /path/to/index.html .
cp /path/to/README.md .
git add .
git commit -m "Initial ARIA SOP workspace"
git push origin main
```

---

### Step 3 — Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** (top menu)
3. Scroll down to **Pages** in the left sidebar
4. Under **Source**, select **Deploy from a branch**
5. Select branch: **main**, folder: **/ (root)**
6. Click **Save**

GitHub will show a banner:
> ✅ Your site is live at `https://<username>.github.io/aria-sop-workspace/`

It takes **1–3 minutes** to go live after enabling.

---

### Step 4 — Share with your team

Send your team this link:
```
https://<your-github-username>.github.io/aria-sop-workspace/
```

Each team member:
- Opens the link in any browser (Chrome, Safari, Edge)
- No login required, no installation needed
- Clicks their role in the left sidebar and starts working

---

### Step 5 — Give team members edit access (optional)

To allow team members to update the SOP content directly:

1. Go to repository **Settings → Collaborators**
2. Click **Add people**
3. Enter each team member's GitHub username or email
4. Set permission to **Write**

They can then edit `index.html` directly on GitHub to update SOP content.

---

## ⚠️ Important Limitation

This workspace stores checklist progress **in the browser only**.
Each person's tick-marks and status changes are saved locally — they are **not shared** between team members and will reset if the browser cache is cleared.

**This is fine for:**
- Each role owner working through their own SOP checklist independently
- Viewing all roles' SOP content as a reference
- Demonstrating the workspace to stakeholders and BOI

**To enable real-time shared progress**, the next step is to connect this workspace to OceanBase on AWS — speak to your Integration TA about upgrading to the full ARIA platform backend.

---

## 📁 File Structure

```
aria-sop-workspace/
├── index.html        ← Full SOP workspace application (single file)
└── README.md         ← This deployment guide
```

---

## 🔄 How to Update SOP Content

When a role owner wants to update their SOP steps:

1. Open `index.html` in the GitHub repository
2. Click the **pencil icon** (Edit this file)
3. Find the relevant SOP content in the JavaScript data section
4. Make changes and click **Commit changes**
5. GitHub Pages automatically redeploys within 1–2 minutes

---

## 📞 Support

For questions about the ARIA platform or this SOP workspace:
- Platform: **ARIA · 新智汇**
- Company: **Sunline Tech**
- Project phase: **Pilot M1–M2**
